// Astra AI backend — Node.js 18+
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || 'gpt-4.1-mini';

const server = http.createServer(async (req, res) => {
  const send = (code, data, type='application/json; charset=utf-8') => {
    res.writeHead(code, {'Content-Type': type, 'Cache-Control':'no-store'});
    res.end(type.startsWith('application/json') ? JSON.stringify(data) : data);
  };

  if (req.method === 'GET' && (req.url === '/' || req.url === '/index.html')) {
    return send(200, fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8'), 'text/html; charset=utf-8');
  }

  if (req.method === 'POST' && req.url === '/api/chat') {
    if (!API_KEY) return send(500, {error:'На сервере не задан OPENAI_API_KEY.'});
    let body='';
    req.on('data', chunk => { body += chunk; if(body.length > 1_000_000) req.destroy(); });
    req.on('end', async () => {
      try {
        const parsed=JSON.parse(body);
        const messages=Array.isArray(parsed.messages) ? parsed.messages.slice(-30) : [];
        const input=messages.map(m=>({
          role: m.role === 'assistant' ? 'assistant' : 'user',
          content: String(m.content || '').slice(0,12000)
        }));
        const apiRes=await fetch('https://api.openai.com/v1/responses',{
          method:'POST',
          headers:{'Authorization':`Bearer ${API_KEY}`,'Content-Type':'application/json'},
          body:JSON.stringify({
            model:MODEL,
            instructions:'You are Astra, a helpful, clear and friendly AI assistant. Reply in the language used by the user. Be honest about uncertainty and prioritize safety.',
            input
          })
        });
        const result=await apiRes.json();
        if(!apiRes.ok) return send(apiRes.status,{error:result.error?.message || 'Ошибка AI API'});
        const reply=(result.output||[]).flatMap(item=>item.content||[])
          .filter(part=>part.type==='output_text').map(part=>part.text).join('\n');
        return send(200,{reply:reply || 'Не удалось сформировать ответ.'});
      } catch(err) { return send(500,{error:err.message || 'Внутренняя ошибка'}); }
    });
    return;
  }
  return send(404,{error:'Not found'});
});

server.listen(PORT,()=>console.log(`Astra AI запущена: http://localhost:${PORT}`));
